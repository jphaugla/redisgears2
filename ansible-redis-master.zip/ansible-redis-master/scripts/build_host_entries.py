#!/usr/bin/python3
# -*- coding: utf-8 -*-
##########################################################################
# build_host_entries -
#   parse the terraform inventory file for a multinode cluster to produce:
#   the lines to be added to the local (mac) host file for each host as well
#   as the lines needed for the cloud based nodes.  The entries for the cloud
#   nodes will include the entry for each host plus:
#       - an entry for the cluster FQDN using the IP of cluster node 1
#       - an entry for 6 bdbs, also using node 1's IP
#         - the format will be redislabs-<port>.cluster_fqdn where the ports
#           will be in the range 12000 - 12005
#   This will approximate DNS - IPs will have to be updated if the cluster is
#   shutdown long enough for the IP leases to expire - the script should be extended
#   to accommodate this - an Ansible script can be used to replace the old entries with
#   the new based on a comment tag
#   e.g.  "168.1.0.xxx - redislabs-12000.cluster.rlabs.org  # node base name
#   runtime parms:
#   -L logfile name  - default 'api-metrics.log'
#   -c cluster fqdn
#   -n node basename
#   -o csv output file - contains both stanzas - local mac and cloud node
#   -v verbose output - lists all database in the cluster with create time
#   -d debug output - more verbose logging
# Logging uses python logging facility - log file is appended by each run
###########################################################################
# todo - everything
#      -
#      - ansible playbooks to add/replace
############################################################################
import argparse
from datetime import datetime
import logging
import os
import platform
import sys
import time

#  Globals ######
version = 'X.0.0'


def load_args(parser):
    # command line args must be defined here
    # the the string following 'help-' appears in the 'usage' message
    # when the script is run with '-h' arg
    # action-'store_true' sets the var state to "True" when the var does not
    # include an argument value
    parser.add_argument("-L", help="logfile - default 'IdleDatabase.log")
    parser.add_argument("-c", help="cluster FQDN - fake - match the cluster name assigned on build")
    parser.add_argument("-n", help="node basename for cluster nodes - e.g. tf-dmc-clstr")
    parser.add_argument("-o", help="output file - two stanzas - local host entries/cloud node entries")
    parser.add_argument("-v", help="verbose output", action="store_true")
    parser.add_argument("-d", help="debug", action="store_true")
    return parser


def append_metrics_import(cluster_info, promfile, now):
# kept as an example - dead code.....
    outline = "cluster_shard_count{cluster=\"" + cluster_info['name'] + "\", this_date=\"" \
                                  + datestring + "\"} " + str(cluster_info['shard_count']) + '\n'
    promfile.write(outline)

    outline = "cluster_shard_limit{cluster=\"" + cluster_info['name'] + "\", this_date=\"" \
                                  + datestring + "\"} " + cluster_info['shard_limit'] + '\n'
    promfile.write(outline)

    outline = "cluster_license{cluster=\"" + cluster_info['name'] + "\", this_date=\"" \
                              + datestring + "\", license=\"" + cluster_info['lic_valid'].replace(' ', '') \
                              + "\"} " + str(lic_days.days) + "\n"
    promfile.write(outline)

    return

def scanmain():
    loglevel = "INFO"
    ltime = time.asctime()
    # get OS and Python versions for the log file
    thisPlatform = platform.platform()
    parser = argparse.ArgumentParser()
    parser = load_args(parser)
    args = parser.parse_args()
    if args.d:
        loglevel = "DEBUG"

    if not args.c:
        print("ERROR: cluster name required")
        sys.exit(-1)

    if not args.n:
        print("ERROR: node base name required")
        sys.exit(-1)

    if args.L:
        logname = args.L
    else:
        logname = "build_host.log"
    logging.basicConfig(filename=logname,
                        format='%(asctime)s %(levelname)s %(message)s',
                        level=loglevel)

    logging.info('Starting run: Script file: %s ', sys.argv[0])
    logging.info('Command line args: {}'.format(sys.argv[1:]))
    logging.info('Script version: {}'.format(version))
    logging.info("start time : " + ltime)
    logging.info("Platform : {}".format(thisPlatform))
    logging.info("Python   : {}".format(platform.python_version()))

    if args.v:
        print("=============================================================")
        print("cluster name    : {}".format(args.c))
        print("node base name  : {}".format(args.n))
        print("output filenname: {}".format(args.o))
        print("=============================================================")
    logging.info("cluster name: {}".format(args.c))
    logging.info("node base   : {}".format(args.n))
    logging.info("output file : {}".format(args.o))
    cluster_list = []

    now = datetime.now()
    if args.o:
        host_out = open(args.o, 'w')
        host_out.write("# host files info for cluster: {}\n".format(args.c))
        host_out.write("# produced: {}".format(now))


if __name__ == '__main__':
    scanmain()
sys.exit()
