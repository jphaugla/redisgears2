curl -k -L -u "admin@rlabs.org:admin" https://tf-node-0:9443/v1/nodes | jq
