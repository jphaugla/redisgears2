read -p "What is the master of the cluster's ip address? " MASTER_OF_CLUSTER_IP_ADDRESS
read -p "username: " USERNAME
read -s -p "password: " PASSWORD
printf "\n"
#echo $MASTER_OF_CLUSTER_IP_ADDRESS
BDBS=`curl -v -X GET https://${MASTER_OF_CLUSTER_IP_ADDRESS}:9443/v1/bdbs -k -u ${USERNAME}:${PASSWORD}`
BDB_ARRAY_LENGTH=`echo $BDBS | jq '. | length'`
echo "Total Databases: ${BDB_ARRAY_LENGTH}"
for i in `seq 0 $((${BDB_ARRAY_LENGTH} - 1))`
do
BDB_UID=`echo $BDBS | jq ".[${i}].uid"`
echo "Deleted Database with UID: ${BDB_UID}"
curl -v -X PUT https://${MASTER_OF_CLUSTER_IP_ADDRESS}:9443/v1/bdbs/${BDB_UID}/flush -k -u ${USERNAME}:${PASSWORD}
done
