#!/bin/bash
cd /opt/redislabs/bin
rladmin node `/etc/opt/redislabs/node.id` maintenance_mode off
