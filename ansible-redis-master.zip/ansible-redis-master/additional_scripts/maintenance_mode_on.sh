#!/bin/bash
###  Warning ###- 
# Maintenance mode does not protect against quorum loss. If you enable maintenance mode for the majority of nodes in a cluster and restart them simultaneously, the quorum is lost and it can result data loss.
rladmin node `/etc/opt/redislabs/node.id` maintenance_mode on
