As of 10/6/2020, none of these scripts are being used by the playbooks. You do not need ruby.
