#!/bin/bash
ansible-playbook -i $inventory_file redislabs-update-license.yaml -e @$extra_vars -e @$group_vars
