#!/bin/bash
source source.sh
ansible-playbook -i $inventory_file test_loop.yaml -e@$extra_vars -e@$group_vars -e re_url=$re_url
