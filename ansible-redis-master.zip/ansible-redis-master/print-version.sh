# Versioning for this archive is done using 
# the ansible var 'rl_ansible_vers' in the file
# group_vars/all/mail.yaml
# this scripts runs a playbook created to print it
# the role 'print_vers' can be used in conjuction with other
# roles if you want the version displayed with that playbook
ansible-playbook redislabs-print-version.yaml
