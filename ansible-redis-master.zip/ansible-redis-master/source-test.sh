# inventory name contains which invetory to use, can override it here
export INVENTORY_NAME=test
export inventory_file=./inventories/${INVENTORY_NAME}.ini
export extra_vars=./extra_vars/${INVENTORY_NAME}.yaml

# make sure you have the right version of redis-enterprise software for your architecture 
#
# rhel7 - 6.2.10-96
export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.2.10/redislabs-6.2.10-96-rhel7-x86_64.tar
# rhel7 - 6.2.4-54
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.2.4/redislabs-6.2.4-54-rhel7-x86_64.tar
# rhel7 - 6.0.20-97
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.0.20/redislabs-6.0.20-97-rhel7-x86_64.tar
# rhel7 - 6.0.6-39
# export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.0.6/redislabs-6.0.6-39-rhel7-x86_64.tar 
#
# rhel7 - 5.6.0-30
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/5.6.0/redislabs-5.6.0-30-rhel7-x86_64.tar 
#
#
export group_vars=./group_vars/all/main.yaml
export license_file=./licenses/license
#export certs_directory=./certs
export databases_file=./databases/databases.yaml
export crdbs_file=./crdbs/crdbs.yaml
