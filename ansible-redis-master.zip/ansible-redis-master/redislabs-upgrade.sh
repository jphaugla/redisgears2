#source source.sh
ansible-playbook -i $inventory_file redislabs-upgrade.yaml -e @$extra_vars -e @$group_vars -e re_url=$re_url
