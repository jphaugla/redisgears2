# Build a cluster from scratch installing RE and some databases
# The number of nodes is controlled from variables.tf
# sleeptime builds in a pause between terraform and ansible so
# gcp's update process can complete
# nodename is leading string in node names created by terraform
# e.g. - tf-mike-clstr-0, tf-mike-clstr-1, etc
# setting TF_VAR_instance_name will pass this in to terraform,
# and will be used in this script for querying and listing VMs
#
export sleeptime=30.0
#
export TF_VAR_instance_name="tf-demo-clstr"
#
#cd ~/terraform/prov-mikecluster
echo "*******************************************************"
echo "current directory: " $pwd
echo "sourcing source.sh"
# source.sh contains env vars used by various scripts and playbooks in the build
source ansible/source.sh
echo "Node name base: $TF_VAR_instance_name"
echo "Sleeptime: $sleeptime"
echo "*******************************************************"
#
echo "beginning terraform apply"
terraform apply
#
echo "Sleeping for $sleeptime seconds to let new nodes stabilize"
sleep $sleeptime
echo "*******************************************************"
#
# playbook use relatively addressed resources
echo "Changing directory to ansible"
cd ansible
echo "creating the inventory file for Ansible"
#
# filter and second grep need to be updated for other implementations
# if the cluster is built with a unique label the second grep can be 
# removed
gcloud compute instances list --filter="labels.owner=mikeclapper" | grep RUNNING | grep $TF_VAR_instance_name | awk '{print $5}' > $inventory_file
#
echo "current inventory - external IP addresses:"
cat $inventory_file
echo "*******************************************************"
#
# WARNING... this might not be good for your system
#            cleans up errors seen after repeated builds
#
rm ~/.ssh/known_hosts
#
# clean up yum before we start - problems with latest rhel7 image on gcp
# remove yum cache and do 'yum clean all'
for targ in `cat inventories/dmc-cluster.ini`
do
  echo "Cleaning up yum on $targ"
  ssh -o StrictHostKeyChecking=no mikeclapper@$targ "sudo rm -rf /var/cache/yum/* && sudo yum clean all" > output.log
done
#
echo "Installing Redis Enterprise: "
echo $re_url
echo ""
#./install.sh - stand alone script containing the following ansible command
ansible-playbook -i $inventory_file install.yaml -e @$extra_vars -e @$group_vars -e re_url=$re_url 
#
echo "Creating cluster"
# ./create-cluster.sh
ansible-playbook -i $inventory_file  create-cluster.yaml -e @$extra_vars -e @$group_vars
#
echo "Installing cluster license"
# ./update-license.sh
ansible-playbook -i $inventory_file update-license.yaml -e @$extra_vars -e @$group_vars
echo "Creating databases"
# ./create-databases.sh
ansible-playbook -i $inventory_file create-databases.yaml -e @$extra_vars -e @$databases_file
#
# install scripts for memtier, etc
ansible-playbook -i $inventory_file scripts-install.yaml -e @$extra_vars -e @$databases_file
#
# add ansible_user to group redislabs - plus any other system tuning required on each node
ansible-playbook -i $inventory_file sys-tune.yaml -e @$extra_vars -e @$databases_file
#
# turn on bdb_name label for metrics - only need to do this on one node
export target=$TF_VAR_instance_name-1
ssh -o StrictHostKeyChecking=no mikeclapper@$target "ccs-cli hset cluster_settings metrics_exporter_expose_bdb_name enabled;supervisorctl restart metrics_exporter" 
#
echo ""
echo "Cluster creation complete"
echo ""
echo "Installing node_exporter and promtail on all nodes"
#./metrics-install.sh
ansible-playbook -i $inventory_file metrics-install.yaml -e @$extra_vars -e @$group_vars
#
echo "The following hosts need to be configured in Prometheus"
echo "for Linux metrics from node_exporter"
echo "Add the first node (typically) for cluster metrics"
gcloud compute instances list --filter="labels.owner=mikeclapper" | grep RUNNING | grep $TF_VAR_instance_name | awk '{printf "node: %s  internal IP: %s\n", $1, $4}'
#
echo "Paste the following into your host file for ssh access"
gcloud compute instances list --filter="labels.owner=mikeclapper" | grep RUNNING | grep $TF_VAR_instance_name | awk '{printf "%s   %s\n", $5, $1}'

