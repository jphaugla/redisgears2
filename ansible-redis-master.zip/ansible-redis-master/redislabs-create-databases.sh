ansible-playbook -i $inventory_file redislabs-create-databases.yaml -e @$extra_vars -e @$databases_file
