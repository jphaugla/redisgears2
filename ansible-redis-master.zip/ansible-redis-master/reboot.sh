source ./source.sh
ansible-playbook -i   $inventory_file  reboot.yaml 
