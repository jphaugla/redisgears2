# redislabs-ansible scripts - Version A.1.2

NOTE: This repository has been depricated - it is superceded by

https://github.com/Redis-ProfessionalService/ansible-redisV2


```
Config quick start:
edit internal ip addresses of the inventory inventories/test-inventory.ini
make sure the license is valid licenses/license
update the creds here: extra_vars/test-inventory.yaml
when updating this bundle increment the revision string in groups/all/mail.yaml
for tracking purposes when this bundle is released to the wild
```



### In order to get this working with your environment it will work passwordless and with passwords with ssh.

## Server environment
- This has been tested on Ubuntu 18 (Bionic Beaver) and RHEL7, but should work in other environments
- Optimally this should be deployed on at least 3 servers. Ansible can run from one of the servers or not
- the Redis Enterprise package you use must match your architecture in **source.sh**
- source.sh's variables can put put elsewhere. primarily used to map playbooks and the environment

## Server prerequisites 
### Ubuntu
- `sudo apt update -y`
- `sudo apt install ansible python3-pip -y`
- `pip3 install dnspython jmespath ansible`

### RHEL
- `sudo yum update -y`
- `sudo yum install ansible python3-pip -y`
- `sudo pip3 install dnspython jmespath ansible`
### All OSes:
- The user for the deployment must be able to sudo (can be passwordless)
- ssh should work from server running ansible to all the hosts (ssh-keygen on primary ansible host, then append the id_rsa.pub to authorized_keys on other hosts)


## Configuration 
- Edit source.sh to validate the redislabs enterprise installer location is correct (if downloading from an s3 bucket is not allowed, copy the tar file to a location you can pull from during deployment.
 Example: `export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.0.6/redislabs-6.0.6-39-rhel7-x86_64.tar`
- the source.sh file contains an example inventory file, you can create a new one for each environment. 
- the inventory files live in ./inventories directory

### Inventory file
The inventory file that lives in the ./inventories directory contains the IP addresses for the servers in the cluster. Groups are not necessary, the first IP address will be created as the master. upgrade will figure out who the master is

example of **./inventories/test-inventory.ini**
```
123.123.123.121
123.123.123.122
123.123.123.123
```
the following syntax will be accepted as well:
```
hostname1 internal_ip=10.0.0.1 external_ip=123.123.123.121
hostname2 internal_ip=10.0.0.2 external_ip=123.123.123.122
hostname3 internal_ip=10.0.0.3 external_ip=123.123.123.123
```

### group_vars file 
variables not related to different environments, paths, etc.

### extra_vars file (exists to work with different environments)
There is an extra_vars file that needs to exist for every inventory in the **./extra_vars** directory. This file contains
ansible credentials, cluster name, and admin user/password. 

## Commands supported

command|value| notes 
-|-|-
redislabs-install.sh  | install redislabs enterprise on a set of nodes | verified works
redislabs-create.sh | Creates the cluster using the API | verified works
redislabs-create-crdbs.sh  | Creates CRDBs | verified works (single cluster only), needs an overhaul to handle more options
redislabs-create-databases.sh  | creates a set of databases as defined in the ./databases/databases.yaml | verified works
redislabs-uninstall.sh  | removes redislabs from the nodes | verified works
redislabs-update-license.sh | updates the license file | verified works
redislabs-upgrade.sh | upgrades the cluster, NOT databases | APIs with maintenance mode verification, verified works
redislabs-upgrade-databases.sh | upgrades both the CRDBs and the BDBs to the latest version | verified works, some better checking to see if the databases have already been upgraded 
redislabs-update-certs.sh | updates the certificates for the cluster| verified, cleaned up. format for directory changed.
redislabs-update-cluster.sh | Update the email from, and smtp host settings | verified works
redislabs-secure-cluster.sh | Update cipher suites/and TLS version | verified works
## New commands (considered BETA ) 
command|value| notes 
-|-|-
redislabs-add-nodes.sh | add a node(s) to an existing cluster |   Add one or more nodes by adding them to the inventory file - still testing
redislabs-remove-node.sh | remove a node from a cluster | 
## Utility commands 
command|value| notes 
-|-|-
dump_vars.sh | used to dump Ansible vars for a specified host | useful for debugging - role can be used in playbooks
print_version.sh | print version of this bundle | role can be used in other playbooks

## files and locations for configuration of specific scripts/playbooks
command|files| notes
-|-|-
redislabs-create-crdbs.sh |crdbs/crdbs.yaml | crdb configuration
redislabs-create-databases.sh | databases/databases.yaml | database configuration (non crdb)
redislabs-update-certs.sh | certs/(api,metrics_exporter|proxy|syncer|cm)/(cert.pem|key.pem) | certificate files
redislabs-updates-license.sh | licenses/license | this contains the license file

