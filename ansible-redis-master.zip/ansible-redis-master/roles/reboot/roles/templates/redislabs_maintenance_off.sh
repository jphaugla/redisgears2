#!/bin/bash

export nodeid=`cat /etc/opt/redislabs/node.id`

/opt/redislabs/bin/rladmin node $nodeid maintenance_mode off
