source source.sh
ansible-playbook -i $inventory_file redislabs-upgrade-databases.yaml -e @$extra_vars -e @$group_vars
