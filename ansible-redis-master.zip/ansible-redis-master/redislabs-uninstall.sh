ansible-playbook -i $inventory_file redislabs-uninstall.yaml -e @$group_vars -e @$extra_vars
