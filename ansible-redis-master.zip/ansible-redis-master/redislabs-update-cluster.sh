source ./source.sh

ansible-playbook -i $inventory_file redislabs-update-cluster.yaml -e @$extra_vars -e @$group_vars 
