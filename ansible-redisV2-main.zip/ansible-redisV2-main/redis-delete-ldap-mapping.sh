# delete mapping of ldap group to redis role - requires the ID of the 
# mapping - IDs can be displayed by 'redis-list-ldap-mapping.sh'
# in this example, the id id hardcoded below
ansible-playbook -i $inventory_file redis-delete-ldap-mapping.yaml \
-e@$extra_vars -e "map_uid=8"
