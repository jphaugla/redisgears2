#!/bin/bash
#
# directory where the certs/private keys are kept are in the ${certs_directory}
# there are sub directories called api,cm,metrics_exporter,syncher,proxy
# in each of these subdirs, a key.pem and a cert.pem file must exist
#
ansible-playbook -i $inventory_file redis-update-certs.yaml -e @$extra_vars 
