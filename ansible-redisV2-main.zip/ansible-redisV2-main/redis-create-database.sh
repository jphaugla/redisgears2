# This playbook will create a single database from a properly formatted 
# yaml file pointed to by the env var $databases_file.  
# An example is 'databases/maple.yaml' - the keyword 'item' is 
# required as the name for the yaml stanza - this makes it consistent 
# with the play for creating multiple databases. A single db can also be
# created using 'redis-create-databases.sh' by using a yaml file with only
# on db in the list
#
# the file 'source.sh' is a template for setting the env vars required.
#
ansible-playbook -i $inventory_file redis-create-database.yaml -e @$extra_vars -e @$databases_file
