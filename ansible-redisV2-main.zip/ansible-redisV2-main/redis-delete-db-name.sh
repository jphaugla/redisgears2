#!/bin/bash
# command line args:
# arg 1 is database name 
# app_name is used as db identifier in the acl project
echo "bdb_name: " $1
ansible-playbook -i $inventory_file redis-delete-db-name.yaml \
-e @$extra_vars -e "db_name=$1"
