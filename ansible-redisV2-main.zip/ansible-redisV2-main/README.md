# Redis Ansible Scripts - Version: 1.4
This file documents the scripts and plays provided by this package.
In most cases, the name of the shell script corresponds to the name of the toplevel playbook
which it executes.  The toplevel playbook will invoke one or more plays defined in the 'roles' directory
 structure.  In some cases, a top-level playbook may execute multiple roles.

The use of the 'roles' structure allows plays to be mixed and matched in toplevel playbooks.

All scripts depend upon various environmental variables for proper execution.  The script 'source*.sh' are examples.
This allows playbooks to support multiple environments and implementations while being immutable.  The specific version of source file
will correspond to an specific inventory file, associated 'extra_vars', cluster license, and a specific version Redis Enterprise.  Before executing the playbooks, the 'source' file is used to set the environmental vars for the run.

## NOTE:
These scripts are provided as working examples of how to use Ansible to provision and maintain Redis Enterprise clusters and databases.  They are not officially supported.  They will almost certainly require modification for use in production environments. For example, most enterprises will require enhancement for security - the cluster credentials in these examples appear in clear text in the 'extra_vars' files.  In practice the credentials would be sourced from a secure source, such as Hashicorp Vault.  Similarly, in practice, there would likely be more error checking and retry logic.  These examples are kept as simple as possible for clarity - they are not intended to be production grade since each enterprise will have their own, often very specific, requirements.
<br>
Customers have used these examples as a basis for implementation in Ansible Tower.  That implementation is beyond the scope of this package.

## Scripts used to execute provided plays

| script  | use | notes |
| ------- | --- | --- |
|redis-add-ldap-mapping.sh| map ldap group to role defined in Redis|roles are identified by role id - (redis-list-ldap-mapping.sh to display ids)|
|redis-create-cluster.sh | Creates the cluster using the API| Driven by env set by source.sh|
|redis-create-crdbs.sh | Creates CRDBs | CRDB defined by json body in ./CRDBS|
|redis-create-database.sh | create a single redis database|example input - databases/walnut.yaml|
|redis-create-databases.sh | create a multiple redis databases|example input - databases/databases.yaml|
|redis-create-local-user.sh | create local user in Redis control plane| example input - localusers/mikec.yaml|
|redis-delete-crdb.sh | Delete a CRDB | requires CRDB id;use crdb-cli or redis-list-crdbs.sh to obtain id|
|redis-delete-ldap-mapping.sh| delete ldap mapping using mapping id|(redis-list-ldap-mapping.sh to display ids)|
|redis-delete-local-user.sh | delete local control plane user| example input - localusers/mikec.yaml (only 'name' is required)|
|redis-install.sh | install redislabs enterprise on a set of nodes | verified works|
|redis-ldap-update.sh|update ldap configuration|example input - json/ldap.json|
|redis-list-crdb.sh | List all CRDBs on a cluster | requires only cluster FQDN and login credentials|
|redis-list-ldap-mapping.sh| list both ldap mappings and redis roles|provides IDs for roles and mappings|
|redis-print-version.sh|Prints version tags from group_vars/all/main.yaml|for version control|
|redis-provision-configure-cluster|install a cluster, install ldap, local_user, four databases| example of multiple roles in a play|
|redislabs-uninstall.sh|removes redislabs from the nodes| uses rl_uninstall.sh |
|redislabs-update-certs.sh | updates the certificates for the cluster | verified, cleaned up. format for directory changed.|
|redis-update-database.sh| Update db configuration using input yaml|requires bdb_id|
|redis-update-license.sh | updates the license file | license selected by env var|
|redis-update-local-user.sh| Update local control plane user using input yaml|requires user uid|
|redis-updt-ldap-mapping.sh| Update mapping of ldap group to RE role |requires map_uid|
|redis-upgrade.sh | upgrades the cluster, NOT databases | apply new version of Redis Enterprise|
|redis-update-cluster.sh | Update the email from, and smtp host settings| uses vars from 'group_vars/all'|
|redis-upgrade-databases.sh | upgrades both the CRDBs and the BDBs to the latest version|to be run after a cluster upgrade|
|source.sh|set up environment for all playbooks|multiple version can be used to support multiple inventories - e.g. 'source1.sh', 'source2.sh'|
