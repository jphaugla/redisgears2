# complete installation of cluster and databases
# must source a version of source.sh to setup the environment
echo "Step 1 - installing software on the following nodes"
cat $inventory_file
ansible-playbook -i $inventory_file redis-install.yaml -e @$extra_vars -e @$group_vars -e re_url=$re_url
#
echo "Step 2 - creating Redis Enterprise Cluster"
ansible-playbook -i $inventory_file redis-create-cluster.yaml -e @$extra_vars -e @$group_vars
#
echo "Step 3 - Install cluster license"
cat $license_file > licenses/license
ansible-playbook -i $inventory_file redis-update-license.yaml -e @$extra_vars -e @$group_vars
#
echo "Step 4 - create new admin user"
user_file=./localusers/mikec.yaml
#
ansible-playbook -i $inventory_file redis-create-local-user.yaml \
-e@$extra_vars -e @$user_file
#
echo "Step 5 - Delete default Admin users - 'Administrator'"
user_file=./localusers/admin-del.yaml
ansible-playbook -i $inventory_file redis-delete-local-user.yaml \
-e@$extra_vars -e@$user_file
#
export databases_file=./databases/databases.yaml
echo "Step 6 - Install Databases using " $databases_file
ansible-playbook -i $inventory_file redis-create-databases.yaml -e @$extra_vars -e @$databases_file

