#!/bin/bash
# use set_north or set_south to set up credentials needed for the API call
ansible-playbook  redis-list-crdbs.yaml -e @$extra_vars -e @$group_vars \
-e "clusterAPI=$clusterAPI clusterUser=$clusterUser clusterPass=$clusterPass"
