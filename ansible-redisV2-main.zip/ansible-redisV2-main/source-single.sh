######################################################################
# Example 'source' file to set up the environment for the playbooks
# this one uses an inventory file for a single node cluster and 
# installes RE 6.2.12-82 on RHEL8
######################################################################
# NOTE:  INVENTORY_NAME designates both the inventory file and the 
# extra_vars file that contains customizations for this cluster
# not all vars will be used by all playbooks but all vars will be used
# by at least one of the plays in this set - all plays require INVENTORY_NAME
# you may not use all the plays for a particular installation
######################################################################
export INVENTORY_NAME=single
export inventory_file=./inventories/${INVENTORY_NAME}.ini
export extra_vars=./extra_vars/${INVENTORY_NAME}.yaml

# make sure you have the right version of redis-enterprise software for your architecture 
#
# rhel8 - 6.2.12-82
export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.2.12/redislabs-6.2.12-82-rhel8-x86_64.tar

#
export group_vars=./group_vars/all/main.yaml
export license_file=./licenses/poc-lic-12-15-2022.txt
export certs_directory=./certs
export databases_file=./databases/databases.yaml
export crdb_files=./crdbs
