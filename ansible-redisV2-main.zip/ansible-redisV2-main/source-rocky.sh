######################################################################
# Example 'source' file to set up the environment for the playbooks
# this one uses an inventory file for a three node cluster and 
# installes RE 6.2.12-82 on RHEL8
# This source file represents a 'minimal config' for a complete install
# it does NOT set the vars needed for ldap integration
# if you are not installing an A/A database you do not need the var
#'crdb_files' - if you are not updating clusters certs you do not need
# the var 'certs_directory' - both can remain set, but will not be used
######################################################################
# NOTE:  INVENTORY_NAME designates both the inventory file and the 
# extra_vars file that contains customizations for this cluster
# not all vars will be used by all playbooks but all vars will be used
# by at least one of the plays in this set - all plays require INVENTORY_NAME
# you may not use all the plays for a particular installation
######################################################################
export INVENTORY_NAME=rocky
export inventory_file=./inventories/${INVENTORY_NAME}.ini
export extra_vars=./extra_vars/${INVENTORY_NAME}.yaml

# make sure you have the right version of redis-enterprise software for your architecture 
#
# rhel8 - 6.4.2-30 - broken for now
# export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.4.2/redislabs-6.4.2-30-rhel8-x86_64.tar
# rhel8 - 6.2.18-70 - for update
export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.2.18/redislabs-6.2.18-70-rhel8-x86_64.tar
#
export group_vars=./group_vars/all/main.yaml
export license_file=./licenses/poc-lic-03-15-2023.txt
export certs_directory=./certs
export databases_file=./databases/databases.yaml
export crdb_files=./crdbs
