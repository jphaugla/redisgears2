# install Redis Enterprise using inventory file and install bundle pointed to
# by re_url, set by source.sh
ansible-playbook -i $inventory_file redis-install.yaml -e @$extra_vars -e @$group_vars -e re_url=$re_url
