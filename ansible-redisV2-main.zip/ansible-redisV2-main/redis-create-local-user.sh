# create local user in Redis cluster control plane
# source.sh can be used to set the environment
# user definition is defined by file pointed to by env var 'user_file'
#
echo "user_file: " $user_file
cat $user_file
ansible-playbook -i $inventory_file redis-create-local-user.yaml \
-e@$extra_vars -e @$user_file
