#!/bin/bash
# command line args:
# arg 1 is bdb_uid for crdb to be delete
echo "api: " $clusterAPI
echo "user: " $clusterUser
echo "pass: " $clusterPass
echo "guid: " $1
# -e @$extra_vars -e @$group_vars \
ansible-playbook redis-delete-crdb.yaml \
-e "crdb_id=$1 clusterAPI=$clusterAPI clusterUser=$clusterUser clusterPass=$clusterPass"
