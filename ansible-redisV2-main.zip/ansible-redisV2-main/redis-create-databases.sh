# this script can create multiple databases is one run using a properly formatted 
# input file pointed to by the env var 'databases_file' - which is set by source.sh
# an example is 'databases.yaml' - it has additional structure not found in the yaml
# for creating a single database
# A single db can be created by using the yaml file with only one db in the list
ansible-playbook -i $inventory_file redis-create-databases.yaml -e @$extra_vars -e @$databases_file
