# certs directory structure
For each type of cluster cert there is a subdirectory.  The contents shipped with this bundle are just example, self-signed certificates.  They are not intended to be used in practice.  
<br>
Instead, valid certificates and keys should be loaded.  It is not required that all certs be updated, although in practice it is likely that they will all be replaced with valid certs provided by a recognized CA.
