# This scripts will list both ldap mappings and roles for the cluster
# pointed to by the 'inventory_file' env var - it can be set using
# source.sh
ansible-playbook -i $inventory_file redis-list-ldap-mapping.yaml \
-e@$extra_vars 
