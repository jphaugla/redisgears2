# Delete local control plan user - env for inventory and loging info
# can be set with 'source.sh'
# $user_file points to a yaml file with the user name to be deleted
# the example 'localusers/admin-del' will cause the default admin user
# 'Adminstrator' to be deleted 
# CAUTION: do not do that unless you have another admin user defined
user_file=./localusers/admin-del.yaml
ansible-playbook -i $inventory_file redis-delete-local-user.yaml \
-e@$extra_vars -e@$user_file
