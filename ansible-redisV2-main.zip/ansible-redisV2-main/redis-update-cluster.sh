ansible-playbook -i $inventory_file redis-update-cluster.yaml -e @$extra_vars
