#!/bin/bash
# command line args:
# arg 1 is bdb_uid for crdb to be delete
echo "bdb_id: " $1
ansible-playbook -i $inventory_file redis-delete-database.yaml \
-e @$extra_vars -e "bdb_id=$1"
