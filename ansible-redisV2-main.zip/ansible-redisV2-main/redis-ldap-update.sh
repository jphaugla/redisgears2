# Update current ldap configuration - server uri,login, dn, etc
# set the environment by sourcing 'source.sh'
# in production replace the following env var with a command line arg
# or an external env var - this is just an example
ldap_file=../json/ldap.json
#inventory_file="../inventories/cluster"
ansible-playbook -i $inventory_file redis-ldap-update.yaml \
-e@$extra_vars -e @$ldap_file
