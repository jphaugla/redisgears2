# uninstall Redis Enterprise completely from all nodes in inventory_file
ansible-playbook -i $inventory_file redis-uninstall.yaml -e @$group_vars -e @$extra_vars
