# This script will add an ldap mapping to the cluster pointed to by 
# $inventory_file.   The mapping is defined by a json file pointed
# to by the ldap_mapping env var.  The format for this file can be 
# found in the Redis Enterprise API documentation:
#https://storage.googleapis.com/rlecrestapi/rest-html/http_rest_api.html#post--v1-ldap_mappings
#
ldap_mapping=./json/ldapmap.json
ansible-playbook -i $inventory_file redis-add-ldap-mapping.yaml \
-e@$extra_vars -e @$ldap_mapping
