# Update database config using input yaml file - this uses Redis API
# PUT /v1/bdbs - no error checking is done in Ansible
# the add '-vvvv' after 'ansible-playbook' below to see the output of the 
# API call for troubleshooting
#
ansible-playbook -i $inventory_file redis-update-database.yaml -e @$extra_vars -e @$databases_file
