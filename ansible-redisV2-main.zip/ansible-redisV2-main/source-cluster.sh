# inventory name contains which inventory to use, can override it here
export INVENTORY_NAME=cluster
export inventory_file=./inventories/${INVENTORY_NAME}.ini
export extra_vars=./extra_vars/${INVENTORY_NAME}.yaml

# make sure you have the right version of redis-enterprise software for your architecture 
#
# rhel8 - 6.2.10-107 - for update
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.2.10/redislabs-6.2.10-107-rhel8-x86_64.tar
# rhel8 - 6.2.10-100 - for update
# export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.2.10/redislabs-6.2.10-100-rhel8-x86_64.tar
# rhel8 - 6.2.18-70 - for update
#export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.2.18/redislabs-6.2.18-70-rhel8-x86_64.tar
#
# rhel8 - 6.4.2-69
export re_url=https://s3.amazonaws.com/redis-enterprise-software-downloads/6.4.2/redislabs-6.4.2-69-rhel8-x86_64.tar

#
export group_vars=./group_vars/all/main.yaml
export license_file=./licenses/poc-lic-05-15-2023.txt
export certs_directory=./certs
export databases_file=./databases/mikedb.yaml
export crdb_files=./crdbs
export user_file=./localusers/service.yaml
