#!/bin/bash
# update a cluster license - license is identifed by the environmental var
# NOTE: this will overwrite the file 'licenses/license' with the new
# license - in practice there should be a more secure way to do this
# 'license_file' - set by the script 'source.sh'
cat $license_file > licenses/license
ansible-playbook -i $inventory_file redis-update-license.yaml -e @$extra_vars
