#create cluster using API - must run redis_install play to install the 
#software on all nodes before running this play
ansible-playbook -i $inventory_file redis-create-cluster.yaml -e @$extra_vars -e @$group_vars 
