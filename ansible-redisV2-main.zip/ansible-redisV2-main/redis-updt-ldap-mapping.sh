# update existing ldap mapping using file pointed to by $ldap_mapping
# requires map_uid - hardcoded in this example
# use 'redis-list-ldap-mapping.sh' to find current mapping and their ID
# 'source source.sh' to set local env
ldap_mapping=./json/update_ldapmap.json
ansible-playbook -i $inventory_file redis-updt-ldap-mapping.yaml \
-e@$extra_vars -e @$ldap_mapping -e "map_uid=9"
