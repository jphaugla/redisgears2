# JSON subdir
Some plays require input json.  This subdirectory is a central location for storing them.  This does not include the json files for crdb creation, which are located in crdbs/
<br>
These files are provided as examples - they will be referenced by some of the shell scripts that execute the plays.
