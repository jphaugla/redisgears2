ansible-playbook -i $inventory_file redis-upgrade-databases.yaml -e @$extra_vars 
